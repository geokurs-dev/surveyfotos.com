<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ab17401467425b95101e6be13d3f5270',
      'native_key' => 'core',
      'filename' => 'modNamespace/35d9e7be5d9ab703be47669025d660dc.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '9b3501a1b8ddc2cd2ef88573ba12d416',
      'native_key' => 1,
      'filename' => 'modWorkspace/01ff892bb7a394585236dbcda5186c1f.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '23ef09c54ef955dc83b8a01c27b35eb5',
      'native_key' => 1,
      'filename' => 'modTransportProvider/2aec66040fd59142420d146b72c83b1e.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2ef854840759c5f81405be7bbd9d0f45',
      'native_key' => 'topnav',
      'filename' => 'modMenu/b2df5b7033d557a5344f30eab8909bfa.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '158382b7f41263f39ed1ed05b25c1f28',
      'native_key' => 'usernav',
      'filename' => 'modMenu/ec356e5530094afa81241a1a92f1d49a.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f0baa94eca7c26abf13e7236992f1493',
      'native_key' => 1,
      'filename' => 'modContentType/35049a9823949904b1248ce9e4ca3984.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '6cadd0ffc86531029cee0d70b488e231',
      'native_key' => 2,
      'filename' => 'modContentType/36683e604b8d79839c34401217993115.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '03b0041f6cf7b8aa35b9564190d05a92',
      'native_key' => 3,
      'filename' => 'modContentType/74b8712613767105028936f5c57446e7.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '9736c9a65078b01a95aa5aef44eca86c',
      'native_key' => 4,
      'filename' => 'modContentType/7aa17393e56dd568e7cfd3be242865c1.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fdbd9e446f80f9ae8b1227fc1e3bf3f4',
      'native_key' => 5,
      'filename' => 'modContentType/a9165fb79ac606c16407384b756a6e9d.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0372a058d8b0834c44bd7401004ce0f4',
      'native_key' => 6,
      'filename' => 'modContentType/b149076da685e9fb56493ee53d7f3d72.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '82845bcc224a181b292520413f00c6a3',
      'native_key' => 7,
      'filename' => 'modContentType/6d6b642600de552a7b1b50f6c7297e1a.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '9c129b2ee976debb0d1a145f7412fbed',
      'native_key' => 8,
      'filename' => 'modContentType/9962b91bd09eb6c1f7e08ed1d76bf58d.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f9b9fa59ef20a76b368eb40045762f04',
      'native_key' => NULL,
      'filename' => 'modClassMap/989d6a6694dbba2077d884e9118bbc6f.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e41c4d8b76fb82a452dcb53abf68ae9b',
      'native_key' => NULL,
      'filename' => 'modClassMap/843d56fbf6dce61b444daab1a5231c17.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b1599d7684cc501c30ec962553be496b',
      'native_key' => NULL,
      'filename' => 'modClassMap/c66e9d89a827ae258d6628f759613f72.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '22e6f28b641c856f243adc5a0a5fef82',
      'native_key' => NULL,
      'filename' => 'modClassMap/753ddf67afcf9ae05e59b13663b71ea9.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '27f960aab61b1554be87ff6e82804b46',
      'native_key' => NULL,
      'filename' => 'modClassMap/7ebe804a10d3c394a0eacc55c86bcaf0.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bd5bc25594e1adfc9cd2bfafd1fe3d41',
      'native_key' => NULL,
      'filename' => 'modClassMap/769735f17d2ee3cd763e778b2f220380.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '173c2b0417c803bb8de762de45e5c734',
      'native_key' => NULL,
      'filename' => 'modClassMap/dcc74d45e7b3272b4a659b4e2c304f1f.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7cab927a8737457bee35d304ac819638',
      'native_key' => NULL,
      'filename' => 'modClassMap/273ca080309c829adc60c7f7177da90e.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '199295b0128f760fdd148037dc24fbc1',
      'native_key' => NULL,
      'filename' => 'modClassMap/ca3207be706a718699cfcb352fb73694.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e01b3a2f69080ae83929607ea490a42d',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/87f4ccc6b8d72ebb6f6710a0ff6b2425.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd6cf88913cc8af00a404af340db2f3b',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/38be080dd3efc4b4ae0cf2dd29533bce.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '961fde4a6678a28f5fdbe1fa846fda6f',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/647d2a7d1aa603dcc0c4df7cb067d0e7.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0885a5bf6268cc8c6cb340704d1aba5',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/80bc8160ae526ca33487592b7004de24.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd44e1c8b28dc01941a5380ac076bbc31',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/5a2436ac21ca389e6b9f6467cf5db2b2.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd9f08e861af8a6e5f6b10713a8f0d05',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/4564fe7250c4eff267e560d652e07522.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6fd15d0addb6f8a9a68b5d595438369',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/de74775b1e796c7951bcd68c93f0d0b5.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8105354494401abbd3c5e545a86a3d63',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/f23bc52f2ff5bafcd8ba8c72e94e72d9.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99941f90eef3784f9a730b3a76a4bcd8',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/fa084e630538a429e91fb3499481e03c.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '625eb4c3728e65d860db56d8ccbd0ec8',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/f1082ef20711d359f297e98539b27f80.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c61f22dada929194be6674572e8a314',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/a9a8f517a8dbed1705ea2c55dc6e9f3b.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc114fb36793f64b8b1f628a29f97a61',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/e158dfe941eadfe8f6ca202eefa7b154.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99d21293afd581f64fe284b265e455c3',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/9bb648d7bf79bad5d1affbfb8723ed3b.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33d1f4e48ef3a844fec0bbd5042c66f5',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/7ccc4931fba7dcb57e46863629358940.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c37241e254657dad2620393570164851',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/f342a42e36018d56891e806c5d42d272.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db72ca2f478e7e98dcb5faa7b25341bf',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/b93852a6136999eaed6c6a970c908ad1.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ed8e6dd2621c70e51c41b89ca91a87a',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/988c7a3dec3278c546848783b7af53e0.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c151707aa03fe8de4d33f28918eb4493',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/895dddb5effda2397b4a10f65288b85c.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '100a855e2409bbe4242cc5d7da0b598a',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/0ae355471c9c0d56d32e4ac4dd8e1997.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b315ee80c40c110978f9297687a9727',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/ba0e3c1cde711b2ce92cb1d3d1652189.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bcf2bfe4e6cf2f78917f50a25c11b4f6',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/1d89a1230c83f958c6e5da58313b150b.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9e724b3ce6690d71e3e448906a2dcb5',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/746c3ebeb12c0b9f783a40cdeb122086.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '495be0cb9f0afefd7d988709e6f5886b',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/f9e560843271ba6f45bd9035b0c5ce6a.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0135570e97d69eef2198446d7902165d',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/d4e10b3e1e5290135da4f12254e3b415.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f4231b3ba158f52f9c6d4835b87b0b5',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/8010fa6e5dddc0e9134c675769d9f2c0.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53cb9762b91b5ea131ea07e3ba4f35d3',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/4d998f0f91d5361ad0acc479ad49220f.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '912e3422930f85cbe90299557c1b2f93',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/f25f9f68685ecf4f97c0889d46940a10.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9100daada8d21658195228ae49887ce0',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/f6870989e876bb1d81bf502b3764722d.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09e8419540fd9f065ee6971706fb1c28',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/3d5ef538f61df58a024a205cff752b71.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a915fd8437458e1af9294a00a42e1ae2',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/ad786100bfd077ee7d12fa5b90ac689b.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a334f6c6ed4f5ce7ba6830ad4705f60',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/59acb47d0fb08f2f69a3590b3e923259.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1cd065712ee5f3669478a33d745ef4d',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/7f4dd80b91b5c9eb6385b3878e7ee531.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3143fff8c3fdd1ac12b5a7e920abd7ac',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/76fda17b548fc0265ea5b8a8d87e0e5b.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bddb87d459a8cf289fdcbc4e330e67a1',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/902e860e0e0d2df97c87c743b77c84c3.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39d33eb26f95d36a71ba543630d1b8c5',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/f034b9be173b3d4cc849412c5f476093.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c484cb780a864912cd78b6a6f45a4943',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/c14240765283c8f9b9a399bd72c84087.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '097d29146e323359e25e4841c2a0007b',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/a63bb7de2bcf26a456e92d0770d69d10.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '036206b19f80c416d2267d6154885254',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/09f687cd6e0f7d04286aa5da55743106.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02af902bd137f82bcab3476eba9260dd',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/ea7225a8012786698714ac94ae8ac2f3.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bf870fe0ee93ba85aa7bc52ed68eed6',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/f4ed15ea7ef23ff489e402807ba9ca5f.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba4793c09f244ae6ba58ba1cff48f676',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/98b302c93de8734a459bfc7f12d9ab4b.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1b1877c74c915afecc785ddb3e2a502',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/2b39240abf00cdad9e537389ab3647cd.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14ed10e833d75c343213dfd491d8aa24',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/ee8fbda303911c95daabf220de717467.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0950cb7cf4148f33b8520aad246f02d0',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/eeafafdf52f5d841b688f9465e058810.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0415815a5ec80cc591ad2a41e1f4ba9b',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/74549fe5abc539a2d5bb62efbd6cd7e9.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21ac988039c95aba2a749312d095cf9b',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/21df0e53663e125f9fda0501df21b108.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dd54d4a871021c2eacaf1081d5d58ab',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/25fa751b27222aecfce42019cf2ad360.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2dcb6093ccbb371963818a8750b82cf',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/098c18ddad55a8c3aedb772599db0369.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49d89fabf51b5af5ad013273ced470ba',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/27711592f31f4d21cac576d97b51392d.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '004140fbe4a8502ae95a1373384055af',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/5b06e92169b3ff5cbc5a1bd5b2186acf.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e6e54e7bc3222f231f92a1ba349e05d',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/2d32ace8a35a6159c78ea805aeca5d14.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0304ea9361bb0f65e15a9248cdac40f',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/b271cb3079e32650edfd52d51f137e9f.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edba40ad9c2940d72960e0d012ed4b58',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/411090e790fd0b5917dc4212a3aa0e43.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c7b8ebf8cf8c9a5c8aaea55e6d13017',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/822fe85816ce74dec407271fff99b9c1.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed3a7ea4b64b11cdcbd1b60e0254fece',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/7f7f01ed8b9f62c6a40ef427903439c6.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '622db7eeaae4c637012fce6cf3b94fe8',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/e4f9f9f934bc5c46c7992fa16d78ce33.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '418e30bfcaf58c903b1ec76c061105c4',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/95ead3a8ce226792595571ddebdcbdc4.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd85b4691aeff46b0641b5dea5413f82',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/0a70ab23a02019c7c41ac203f7686373.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a88ecb0b2f7ee237a2d391481d3c449f',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/9c88be41d40566b05bca4a9faa9cff70.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '279d8743f91e03794b8046c757532b4e',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/8748171270704f7f910d5a2abb15f3ce.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9766828ae1e00dc3f40e7fd5b17e8ba5',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/b5863913c7d8f646644cd9351b4e03c8.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10eb7c633fd548edfb2addf3dad6c1a2',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/f8ab40c32299443233394591f2c52b07.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2561ce56009e54ef63d25285af2753d7',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/d14796f36b2fb5500734b4324b2b2ab4.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c39f37875244e87c1909c991491d19fd',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/75caad009da47acd05659acf80184e3a.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5417266f82a3423ad3abd120fe538287',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/02f44c2008fafb470109eb5513f98582.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '739b04ef880bf3ae4c967f65eccd0857',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/f86b4a8f9667b254202959cce3316a48.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e3d6662863859db8adaeda218d8566c',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/4d3106309785fdad9369d2834e594b5d.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c67801adbf99cf2a0986ce8431a7c7d',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/d00827cb2d146b252898691bc3736615.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bdff73872b6bd81d7691768440a777a',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/a34146b7472b39a27bd84799ed5752d9.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '493dea4b1e235ad040499967685b8f70',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/b197eac1c0edd6f9680c0c4f720a3a07.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e1c2943d4310dae6baf74c02f59cb7e',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/096302b5bc8ac41d5aacb13fb59830dc.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2dbbe1f68eb34fbcc0740c7aa959d3c0',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/48ca83f04d2680797ddc452e1a1d2bf0.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '501bfa2eea73f84779c587ee0babb395',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/8147b1563516b51dd7620a7a6733f054.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '538e1510b75ed0e610bb5b2849a07ff0',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/74fd649c97af0872bf84eb8ca00cdc4c.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a88f9f225e714397bb44bf5f6ee58ba7',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/5dfc65bced926fc3aef47877c3064f96.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c058455d1a6d501d9bcf158ba2daa6ae',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/10a3911cda4a6f0566f559c20f2d2be7.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccd28ebf172216fa4d88e4a47826cf57',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/f8ca6de979ef67631c7a486490a2efdf.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b891ad162526e0eb942613801ed6f2cb',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/bd16d7242080a3b021ff43832874f55a.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1146e57daed2cfb90140a5d892d0fed5',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/f28f06b5be027957cf3e3ff5f9a3c97f.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c382bab19dffbd85370c273384c9fdcf',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/db3a9cc07aacd96a819cffe341fb5879.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fba42987961928c18173cc3c504a5680',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/da395e7842df69b326d63df58168a98e.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1b483a3a2898c4cfacdafae81546976',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/098f6676e5b21825f5e25633af66b265.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39e69b7f87f09bfb866f5e3d9c7eeeeb',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/12c293d0cbada90a2934e385b9fc18c1.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4919bb5680d17c5a853d24b46cd050f',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/dbbf5f508de09eb8cc79f71e45ac389d.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ada30bb54952eeb7a7d198dea5cd7cd',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/cf893aa9c31954323a6674e0a9e55fcd.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '990e3b2fc8eb798916eedf750d05fb03',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/7e78180ecf00a817cb0b60618e27fe82.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72dee819bd0e96fdff2d85068e659a65',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/20ad8d33a82c6fd7252e871d433862d8.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f2575a84342cb837cda3723a80020b2',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/75c82081fbf4bad1d5bc28da0cb992bf.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e02bcd2b643262d6bacf76a69c783370',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/7f7baf3a825e0fc9f950edb5043c310d.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cca433d132344d20541562f4b0306fe',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/d10060f978dd70c4a044dfec98eef3c2.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ccb4a5fa8feabb43770851b6b66ca83',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/eb06d634713092bef25075139484b920.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b31a45a86165973437d6262009b56beb',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/60eb5568433f5ac395cee82b2e49813c.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '907a6667713a11b27e6b2ae464526bf1',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/4cad8d07325dfc51760d8d5a4a170e71.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67cda8067bdd0fc6a09de07dc5019022',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/0ba47f6597a7a42eef0b410c4ffa820b.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab193478e0d6e0c432b9ca209719fbda',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/0ec72ddce2d20547891fec8a1907dbbd.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac4fcc9d84126769227ddb1f6502ff67',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/4a8565ef965624ea3a8a477ccd51a990.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44a0de4f334783b3b1619544c9fe90c6',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/8337fe735dee140d2b0433b3bd73ef68.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77c5dc17203da4719d0827e3dad188e9',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/0aa8723fbadc12a4a5b723b15d3f575b.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01db75456393fe66c884687221efb2b7',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/963b337f5e5bd2726b43566ad10d951c.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ea38c9057002734e86ce44c4f74216a',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/b7704d0ea26009ecb7786dca8460faed.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae50062e8d81e29dace40b38e4042874',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/df94d224511e2533c963df1c619348ab.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6618e80ddf19bb7c6dcb59a53762792c',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/8fae0e7775ec4ef69494a4644b62fde7.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd4dc5aafdc9903999e46a5a4e6e65bb',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/1aff6f23eaebb2d97303671b7a94dbc9.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8173381fd45fba1a224fad40f52868c1',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/e5447e0d8a39eb338429847f1d7fee00.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '792520b294ec0f173a0979efd1b70846',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/ed9a622d645194b1adad7ec75cf9cdf8.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f8226ebde73e524279f5b094feb001e',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/0cf70cb9a325a4e8a0fbe5410cdad357.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a28db881735eace68e07d29eaeff3ac',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/6f8332b967752317839418be381780bd.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3e192f38cd10d8d60cfc690a9d5d590',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/d937a0aa92de89008800c995273fc6d4.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff26877b4943de34239076b43e7f2818',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/f70f2ada972634a6990cfb6b9da3f307.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1639205df2363a942a8006e834f29eea',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/333939c6fe1758b0faf000fad7512006.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44c3bde0b56f9e97528c0bd8b0d71737',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/2d944a3dbf6e06ac8fe8ef4efd0c864d.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35c072f07157b2471da7620b106982eb',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/c749001174dc191e29259d3362324e51.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '441f60638c8070176b7bf8be47d5bec0',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/a819488d8609d57aa606e0fce336f941.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27c29e5531af31f9f4ac1a80e9d21786',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/ea143ba1942b355c98e5b6d50cedfa7a.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d7c7666b0b513f5edde524db898019a',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/c693339d27b931f69aa6c8c6aef6f93d.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe1ef8864b478b6af708a66a866585e0',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/0aa9130ba9f4e3d9b0cc9e239cbd56c9.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2007f435e0abb02f8779e968ceaad6a2',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/11617667e4daf89575eacf5a2378c11c.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0fc9fcc59d4da72f1ec5b5cf693baaf',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/25bab78cce9568668c1fa2df5c006f36.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e77923d9e886e3e7092486999c284e1',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/75918c44ade5d9df6ec950f7d8dd28a4.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6c2ebda637ba3f69b7c74e01ced1d3b',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/947dd1fb96ef65befc7d932bd23ae59b.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b6283e04673db32b1fea26250438aed',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/57f7ac280ac870b36fe526079bcec04c.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6cbba3d36ba19d6eed0f2f4a6578b5b',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/93998c12cc06fc9c7b16a381c2c89317.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '439c6710bed416e5ecf6c5b570211473',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/531dcd5139ddae31896af1bc9b30b541.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f42131db7fe4b7e5b4655b03c420864',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/bdad96321642561f17368db50d66f396.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1cc11986f0c346c865b8d45153e9df1',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/32600483c2e1ce4537df93e3990cc31f.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'feaad3b391845a9904de1522028d3adc',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/bf7a6c09bae56db638aa259c257105d9.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bf03622be46e6faa60f42a4e0292f59',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/5049256cbb9a9fab3b01d6838e1fceba.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1baee1013e1e40a460bb318bd4e30c27',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/7caa2325ec5479951c44afdd8c1ed8f9.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '329183d565940903cab53e54bcaa58cc',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/0bdd57bd52e73acef295315f9619abb5.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5628808bf2548779e9fedda7dd0e45c',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/9646a2499b0e0ceaaa0816aaf429c96a.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0288056c2445c026da01b6579ba42989',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/67c4ec01c2243b08c88da091103d5713.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a180cdae00422fcf15a559a27b53f46',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/73b1ec3d0abe6aa45e769698bd2f9465.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bced6b21c2a1e32aa5cb5ad1d75850cc',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/6b48d1136a6531d5a12e5161d785b8ae.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7f788d374e5bf10c1a8582d60072406',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/0603ad97fe7bfd4e999f35591a136be2.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7616308e0c780bb8ad6c6a4222132343',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/67636db52fa6329f4e7b31d5832a2a77.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e24b9e56ec02da60a207f1a14d9fef43',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/b41f5f04800e92bc578a5206828ff336.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '24af05897a5ff78bc82ad25e56a75281',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/e03b62bf36fdb48777aa53ac92c7aa57.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd24ca856e6990a9d6ab81c4a4fc18648',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/f41fb648fd659033355e017e565e1496.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d6721329dd303145523f69c6d5e3c19',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/3f2469ae9f3a108ce13bf0b6f54ffeeb.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ebcdb6a740a4e2be8959814dc632d90',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/406531d8494197fb4857c31bb0742bc4.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ac8dbc0aebf99c5392936382f191b59',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/a1862e5e9455794a0611dc4fdcc6c748.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1c0946cb5f248a11ff1f344a0893bcf',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/1c81a8469fb20b145ef21d870c59bd23.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88999ae9dc75a7b0f8b78c803541d182',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/28b23fe7d2a49cb8ad73af012b9de268.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26fcca7600b558b20df62edfdcad9e09',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/cbaf4ba8faa8efed214b721d31eee6b3.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a1938fb9463612157f7d2617202e7cd',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/80fc55f619782dcad3dfeeaa5adcf09d.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a62ef07189941b5757243e06c379f8cc',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/ac590aed9a1a2538c694c8763b60d4ca.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '008b795617988288a1d71cb199023896',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/62341ae055bde1f78fbba0df0f27b345.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08e72b5e1a5e81a870a8f039d9ceb00d',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/19c4adc1cd7561c638c95eba78d89764.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cdff54cf9e847fab41221adccdd0db8',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/a656a711c78c8b414d4fe8f93345a657.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c99ae679b54c4b1a5a3d9e552a1bf1d',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/9114cc7067b131385386374f5b12cb98.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ce0cabafec197fc2602700c11cd03ed',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/7c9a9af986382533e111c20cf5fcbb8c.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e758b0f3631bec9476759d0f45c0b58',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/2e404b7e74ad140491a3110f47dcfad9.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1dc3a3059fc46dd15293645977b914e6',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/1594d6dd6e9d92dca43cba345e2d6fc0.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc5b2bba1b11825ebf59f59d84694d1a',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/1ad3edd491aee8913b3f52c511ddf53c.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c46e2beea112279d83aad6989e50f088',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/bb36d4f1eb78b241020b8ac08a4bf167.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c913fb162232725dcbe2f9c0a3943a3e',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/cc90da5678ecb4966c6e0567111c2893.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '207095c948da12cd31a0b2efb29d6b47',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/d76aefb5966054de97bc5f9c00c723fd.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a9696eaeb9a0854946b62d3c3fc271f',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/e0f6e09876b90bc02f37421ecce57b5b.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a65cd97fd16a624d06b2a1b56df4ee0',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/43593c3446406bb89e5509c4d3070998.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08ef42aac0965b7b9272b17b6daebc2c',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/3a7cc72f192b9c025c5cf5033480c01e.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '795862a858914c372e0875a54d0e4eb3',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/b3c06d6c16353d449dcdbabd4f37053d.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81d43dbab8b29577c65ead7d07d4f8e4',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/882e84749168eb84d14882e6cb023f7d.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82ec83e4611668847136088e67d2ca46',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/f3b392be5eb55410804287de61bc890f.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '601d1df8ea2225b92239022bd450d0fe',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/b435dcecf87f238967c77dda9b3edb52.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8004536c6c15943c30d5f26533fbdf6',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/9f16095aabbf3d887c8f39cda22e5593.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c4e48641817d038718b60e0d25c5ec2',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/964a920c77c582adc675461c2e2d741e.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c07ad4194144a9673bae7c03266b432e',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/1b8b3b940c3e8e9e483a8f0bd88f177b.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b15000afa093416352e1353d671ef344',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/c6928f3aa3c29cf0957694875669b6e9.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ceb74dfa38e3efbdce4e7506545f9d79',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/f6eb8a5725f57c184a2ee77ae48c021b.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd20441c34addcc9daa9b1539e7313957',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/119ada5e3986514ea4b1033bb232e91c.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c425763da05ab4ca25a2321d8b7cc57',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/783f1aa2a1adb59e6c622ae23e1e81eb.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2d0d0c21b81c39472ab6dc0757aded7',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/a0108213561fe1bf4632c8e838dbff3a.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58a7acf87097f3b34bcaddbbb0133a2a',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/7b62978be818d3054ed4b7d6719868e0.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '118536ca196d3873eaea4143c7fc1eb2',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/ba7cb41b5256f086eddee116275fd3db.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9384b73e569ec9d80e9e8aadc6fb69a',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/7ebab95c8c93d6c5a9e54f9c4f310da9.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa3d3e208c747f0a2ceba559a5101fea',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/7cd93b6db161e1bafac9862e38bbc071.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4984681d0d13a675de3d9690c1d18435',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/83363694b3fbe0472c17a6a73cde89bb.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f958b00ddd3ebba66d4efbbb2cb403ea',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/dc8b69f149d5f914cb49d91dd9bba6e2.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0eefcbc082b783ff1b2728b743028c2',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/f7cc9aea8687fdb916476ed0f1546472.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58df979c5bd4afc4af741985720c6773',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/0fdd5b6675e34c1e747c12e85fb6356b.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8551e4a39038514c0bcd847ddee207ab',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/71fd27a0a4ddc7449e38b1ed3d7b05c7.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e2c23df9bcc47c0ce6ccb318da87305',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/94f69fd483240f30e2fa6ddc5ce3dca5.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd6225edb67bab83181f813eb1d23575',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/b3455735bc000cc0c2bb265b23d99dcd.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cd6387d8dd8a2f4fd652034d23b164b',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/bd2936849a3bd6557b9acb83cba5193d.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8b7870b1ee28e332b0375331eeaf469',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/49e7136cb24c82dc4085d1c0ed6e1ee9.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b466eab9a85f7cf6dd4778db627cf8e3',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/d368df318ec3039a15cb2246791b1b3c.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7698b46f13c01e5921c6af8e037a50a',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/0e67d82328b6bd898f5f14edcf230a68.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '986a58e998360c068a146e0edfae1d4d',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/8aa5565d9600ff624d589fd3a02eba2e.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c57cb77ffbb54f30eb890129c9f6bf3c',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/766a715ba80a01c8547957ce04c18b2c.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c554e9b9f0f3132289e5bbb469f2f8e4',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/cd84cc31c2a70c3acfc2e3eba381e96f.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed4f5007929c5874432a4f5cb9773b1c',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/a60b405f393aa23b3d97a0c1be80070f.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0f9be55db46ae85851161abcdcd1350',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/12e5ee59d393bc554dc1a6fff982adb4.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '378675e742cc77050d6009094c47f5e0',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/492cc5e3588d153ad3d35f108f089669.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74b640dac4e8e9c2ae50920eff539bd3',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/ba27732ee81fe8b355e9802fe9b32397.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '426d5298acf498407cf0a06cf4229591',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/c70fe6ed00dc8e72baa58219b19f6503.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '794f6ae4a56193ef553a0ba319843479',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/39f200dda978c03391fa22141b946803.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '513a338d751ccf6731253d1eb5b87d47',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/951c6cd17ab96ef4dbda771762eefe69.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27a94c44f454e35f65bdf4d8d5f53f6d',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/2af4a0ed0fae0cdf788ff7580a1332ca.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0639386c30f9975286c689fbd78a7f3e',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/3331997508c1e23e8976833ba0db00a7.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '607f3c7dc54dd0cad1598d2edaf8f148',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/78deb0242b371906d3e27a4bc25fdef3.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4734f08c540de9f670241b86981a1c42',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/76d3870f063dfe1a5a96907191d82a01.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bd171fa064e262da8512b363961121a',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/4b04818cfc10a33582e28e0c65a575c5.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e37eed36aa332c4c07351fc829691e68',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/b31d8d3ffcd21d218582d4e6f959ba21.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82a6b1666586bde4290c5c5e7e2a9711',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/23a8a232e2427465ffcf60239147f980.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d3c273f05ea998cb6f03fd2e326209e',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/9769a29e40e1e487c3774c7d35757fee.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '977a85a5ef8373700a18de45daf5ef7a',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/2b61f055cabc62d41b4877af317e999b.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a666140826026ad15be2546bcec2430d',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/c109c26221d338b9f811a398ef928e68.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74b0abcf5a0e3db2d0082d5ac7093d9f',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/36f7ae6bbfd6e42b9cd2334c6d2ff777.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acea5f540b0de5ff1aa8e5b34a76e7d1',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/c0579f72d7828334f993d617c2477f19.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b32792e2cc5c1807f32639c27cd8274b',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/6c259a3ac4761d88acd12d237a9d74b1.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd485f376b0fc7860af0cfe8138e0bec9',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/de2ceb2182bccdc8568d2b1210e61e81.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '699b36ca23cbf5ea534fd6d9f35bdc79',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/db2af8c0c934e8a5f5fde6ed667ec706.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b78653675f84642f268dc8d395edb1f4',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/3379f280cce872e9e74e46a3b8662b9e.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '048089e2baad2c0a870063c471db6dd1',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/15d2d99327adf56aac03a12d972a505d.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6efb7bc1c38c6b9397fe35b262193b4',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/185bb2a68020a5d1c48b0d946447b981.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9c6a200b0e61b2443d25c5ea6472ca2',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/5c9f75e3b0a7f68d9bbab8f35c6a9f29.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a0a32f11bc8227bcc268aa184470c86',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/2ed2b5b22ad5ab3042297b116d698b00.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '777346fc767aa9947393a52ec2fe5d44',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/d3742efb0ada7d5c83d8a1a99b597d00.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6d81ceb09e25b3a2ea25d6a6465f639',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/5fea6bdef1b3ea3532f403442be91dca.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f4155fb8744d1c502e16695bb4ab98e',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/2a3fdeeb80f5f1b215bf6d9b50952135.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e142a9fa66cf3ccf8f1fda72d1f23990',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/9bc71fc3c51930b4813adb8ad5a431c2.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70b94a9fff690f183559c76aa6814206',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/b4093e6a6834e367803a7e42d29d8141.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e29a3b5b4d9fc8c67f590e8b67486509',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/901a60de76ceb79da0926c9470e2ac80.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7c5a28e5b52b867396c04b1ebc88bdb',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/6984e2ecc637acbda25a49aed01e1ce8.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad6f398dd3efc128ef8a0cadb935f34c',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/5ed56e735b50f0e716e9c24e6389cc56.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9d0583c0ca1c0bae967a1b501f58fc7',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/e8ab9325e57debf3391233fc4cf8ab1b.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7ce3c7e6443c310608706da3172c76a',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/6c0ab44eb310e9008088173f3b785f9a.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aef1a36e6800a570ab5f370d4bfc52e2',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/dca1864f3bee75b1b575ee3c58bb211c.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95aa2f815b7f92fe48d060b5352bca2b',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/34ce1f1726210083c7bc4f5c089f176b.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '477b23d5ff48985a7029d794d861095e',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/f214b2dcc746505127f2f75a56b87b2c.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24d3e2c959cef3087dd2953fc5d11ca6',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/fa95c4178435f13ada3bb728411cbf84.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18df00c55aa2ac7f0dcc37b71abdb4a6',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/3a17c5c9ccb0d5c48d18547ea3b2ec48.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a10a1e5ecec42462c0b0b8435ea9cfe',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/e902ecb5754ed8c2c36d2c94ac5487c1.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cfb9397422f8e45223647082d0f88d8',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/cdf4e8283877229badc456168368dd39.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87c7c3c38da71ad5154377dab0a3d316',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/c66436eab093a6ac4e2fc197d16e53a8.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb587786b39c8adf079f25655d74927d',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/cbd5f57285405ab66d5c2a4d490a16f1.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3076aeadfd1251ba7288e6b39aa2cce3',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/64915d3beb28b307774e9a299e3122a0.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11475421d44b250db5beec507b3fca35',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/5960f747be6e732d3ad0e53eb39e4274.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ecb96f323a20c6034f1ff53a91c7bbd',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/fd8f040b60903ebd498c2f73f4f7491a.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2910ed3b1140aaaf6eda72399865b9d0',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/1ce54fea453b610b441f2124c1f3e951.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '153ffc1b257986330636593f2782f90c',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/58af63c60b3731e5c165b87f544bf4c5.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcdae149b53de065cb317139dc2f50cd',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/da273fc14d8377c4dc74da31b9b6e769.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c713093bab145ffd60f2f50dee0a924',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/4f7b4c62af1648e3e66285a3b68c4537.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58b7beb8992e712c2e6c16b6696d8af9',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/2d9b5af9bedfb923b4c1d0d838e1a7c3.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a584b759f158c660467f003e4d83f56',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/65b94187da455bc7429cc59f199cd8f6.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b27acef3cbbe147a13cef5ecd3b5059f',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/1cc18dfad49e3c80fabd422a6462f267.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f6b16b79965a612211104bf80e5ab3b',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/d43f94e0686d6dc57cc41eec66ca8e4e.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf3c1c9ca60ec4ea60e640bfb94990fc',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/ad2bd24cc086c951d87f91fafb0cad8a.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7edbfc90d99cbb02bd7ec88282758c30',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/69046325b5e09c164599ca3951f16437.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99ff2bf2822c102646e9674bc37abd2b',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/46b7fe10cc960f9c9059061cc091e1eb.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3d074241e53c768ef63657a39dfc490',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/08a53c01bb3af4736ed17d31583d303e.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c86eaa568a5a0ea1aa8c71c0c4bdd7bf',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/5e78e8e549276488f0426ec35a8be256.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96e6be64b05e5551a0d38d0e3b839dd8',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/acc2807ea60907283fd92d995dd307a2.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ca677c42892ff2bb2eb58fa5bba022d',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/bb6dd35366d605b006614bcc038761e3.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0a0a29b7de15d5fd6013a7fed6f69cb',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/566247a7859036e1b051104cff1ff658.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '904893543a1276bb602fc1f8980fa3dc',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/0acc74088860d89982c55e0eea40c18c.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37b646a282c143afac6c8d6870796744',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/44ff5d52bd9d0392f60e64f122406252.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8bd2e1309f78d020a0600e8be46a538',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/31f8496fbaeb967819cb76d988efca31.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abd9e0e3501221ccda03da8d97e82849',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/07b6c5c7cd40c8102377af60b0dc9dd6.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0edab6547b9fdb2446cd8e03f2d826a',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/fcc073055822facdd937372b602f8b26.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6ee68490aea704525021aa8d9cb7b6e',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/c5ff5ae124e9e0c22a86a66683803e74.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9283c85eef722f221237c0fee0deeea',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/5ccc88db7d5a7d00eb4a64fe6c93e96b.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1f4f3aeacf6a13219caced197642782',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/eb82ca7e51a11f1180f0567af5b7d610.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71f4437813f9104765959170a65d2321',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/4e6a8664ee88917af3b674d8c5edf189.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01dcf8e6d36438c083faa617be064c89',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/9014732c61ba4e89e44a67f2ecee0106.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44c5b707002c9916f69fcaab5167104b',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/20df3bc2fcd7e79f12cb5481cca3db6f.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd0e956ff3e9469d4e7ea3e630d28d73',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/f1795ab2aeffbd47e2b35b5e290b9e7a.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '891e937a7273e27828fcc95095a7b27d',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/572111cbc4329c6f14990aaffa39b894.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0fd8d6598288c8588c3b3750237d27f',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/f897d11d0d98e4fb953e85a59e14f459.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '442f3597d87b9633515a0937fca42ed5',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/93934b7fef15315d3f372fb151c566d4.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7a0b0ed7ba7f5d93396ef0dad3012aa',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/f68ffe73d15e4981bd5927a8e44d456f.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb5687d178c79461cb79c274d6962bc1',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/b5e6712c19cd44f30330c152c3bd5824.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76beac6ec2b492b13f70f204efa35840',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/fd82c68047a8ae6afebdd7af50291c79.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c7ae0538cd15cbc2d1a8528e3a553f0',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/772640c7133a310ce4af11db9e61e75d.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44f0c6153f7bcc7d6fe23e43ea115b95',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/d23ca3201a31dd28c2323068f678b4b0.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3edae1eef881f04ecefa944e37452a1e',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/7df48b510fe2a65be12e1cbcd25b5ae8.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69182b158af8ef1f4b2d209c9af9436e',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/1851dca0d51a7a3f73e35903c7ff1fc4.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9058e697a947616f5d556330cc4e40f5',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/3e34044100b4b1b962069a25f0495672.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '879795422cad62156b0b5919a2d93149',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/b9f48ea43d5671351fe3a0208ecbe991.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20adca0ea9ff7adf5becf377594ec3a9',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/ab3261e70a5413bb31d9540bdf9b23b8.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3fd85131cea8c9edc3a256e1098b681',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/a05d1eb9cfdf9102f89a7b68da7336cb.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae8ba3235309a55db310a322925e4a7c',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/2c37d9f3da128828389793ef6cfb3178.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d0fd28acbc8312ac388ca539a5feb0a',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/031caf93ecc643031345d8b32da2d1f4.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eebf9df1e43726b0027295ad9b8a942c',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/dc26a70ce6a91f00bcc3808355238219.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a063edd83a42f54c83ddcd8c0663e1f',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/94e5005fb9e3b0bbfac747a1ead7b998.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55f58bf8c9a7601226fa3eb94a29280d',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/d99bd99191dd5a83e348d346e2e3e9f1.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '419721be2266148a6a6a1c09dc6f1c00',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/a70f52001411e5a77e9f4e801e603f22.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17be2c90146163724e9d7ef72b165cf7',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/a1289cbd8a5513e1a2ccd625489dd974.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1934c4619cf0f76fcc43b0ac42fec06f',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/7e3c573dcd76d35881897c6bc9ca8095.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95295451632585db66ab535726e41c28',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/2a97a2550722950b7753e727d9fba0ef.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0e8f62f7a923c007cba93f59a282621',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/ab119685ff042ecced20b788410fdde7.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b74cb8627dc2b5340d48be9dc76b6bc',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/ddca5294f335ab6909e8c84ba0fb5b9d.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '662be59be805553f3ccd378624a4a5d1',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/026277cab269b8c25f67741f055d1a91.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97f7fc8dbc130a0a1241039aea343d5b',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/187eae59d43148c1194bae5d78ed6a5a.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c86c5c769c62fc0035627a5c44642f86',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/6c09412f9c3a60cb714f369e95f7e4a5.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd584c57f97569d394fb071b1a10f59b1',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/a81b5d2ca38513b160ee480914c44bcd.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '710e4c88710a4ba3223529b876ce2e4d',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/fd1e6c309e9cc37a1d47829379ee653a.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18925d6d1edddb1cff0a6dd5d375fc0a',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/f360004e9f3081af965b4f505990c5cd.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf6fc0e98a98e478afdd3ab7242e9cfa',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/e975bce0de606d9a3989bda9d12f7682.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '358699ddf37bbb2ef9bdf8ef7d655e4e',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/1ccfc5f3688a1e38b061f1a0bb682565.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f9ca815b715dcef298f1226a457b0ac',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/e65269ae870684c5891aa023f10532fd.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cee93d2a6e1baff6c5e069fc367e146',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/a624cac0a10a6cf565a0c45cd32be7e4.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c144f36bbda84c07b500a8168f916834',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/1aa7da2cfc39db6421e7b22685deeef1.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58405fc5e2da9fa4a21d889d3d27a45a',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/52a2c284cd6b1d6bcd8d82e05ed15603.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c60a90e549621978e9a3c431a0a7cf5',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/baa56aec8c3df1d35edb0c2dea3fd52e.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b02323dcd05f5de0ca7d25f50b7f7241',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/27c14c58d9f058ef6f336bbecbc59014.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '430be6657ac9a98046d80e853f12d8ae',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/7ad99e7a26e52496a14c94c6244c1a86.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c86c55a722da549c8f7c107ada958bd3',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/74a2461e8eae423c1d0916ea488dedd7.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03f331d32fd3c0c21f53c4ba4dbfe836',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/8e97824b85f85f7e4ea2044db0f9344b.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93064cc983e395db8c8e5a4c4d383930',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/6d42c498924b8fd7a600da7d43c32372.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0379a13a2173ab90c101eeb4e20211c3',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/e2bf678ccd1b612cccf460852b282e05.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddda6d88c71ec52ab29dfffa53005740',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/fd5a14c8b751379c3b9f9dab198d90e6.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f55470fb6d0e8fa9e82125a030aa051',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/f08529481e07b2825a4be873ad425ccd.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b853d12e16acfd8372bab1be97ce6154',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/92ed815a03aebdd3da66c44a94babb0d.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99a2eac1b9790702780b870e87970db6',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/cba45b3e40e5d20aec9d93a4e874f8ad.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1ece60e66e745286502cd24362fa283',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/443040e4cfa7bd67cdd14e820af4cd4e.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b609c909c879710a12643b83560ff3e0',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/6fff48a8af95c25279991a6c8293e407.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90c12cb52fab705b660944e10a481993',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/5532c1a2ac5ceaa9d1e22099b17e29e4.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52633ba24bd0e851e943e5a8eaf453c4',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/185000d94dccf37aaaabfea9f51edc00.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5817adbbf8661e64aa757546299aa7e',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/4500d0bab5d77d52241cfd847c8d4f05.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4aad328fe3fb8cd683486c07f2111de',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/6d79a6e93db90e1016ba01baa1f785c9.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8383e777bcf221ac9d4158066158ed5d',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/768eee22cd604f12eaf4dbf8a5e8cea3.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba59d8f0789c2a75e7841f78da9c7c45',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/bf59eeb77bd230f97b9420ee0f65f957.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dee7f5d773a4f0cc4cffebc353a62f2b',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/7b5cf4eea2b0a7018cf5264cb86647e6.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f57c5527ddefd4e9db1c270dd622960b',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/0fd3302b285c7ae72d1a03fc942d31fc.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32cc742bab41e929bfcb27a5223a27b6',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/e4843671b2959e295d088424d885185f.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9fa29cbeb294cb4a1bf9c8a4d950ca2',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/a8e094e257be7f4ec5302b083fbc83b1.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56b9d15f815f8f35bb165fe208f98907',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/c806a5109a3e00ddac0faf2951a26e29.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62c72b6c0c4e0f678f3f02682d9391d5',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/4eb142e03fdf0b9e64a38dbddb567b8a.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2c20efb5bc0d2bcf8fa6588037e8b8c',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/26d0047b4e2d8addec194e5cd6658017.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e23cee156fd8de2191501907c1df0550',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/e6c536fb5e7ec9244a53bf74e29c117f.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9a923a36fe5750d8d32093163b740bc',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/0def0f5eac8275252536b849cb68a920.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a13b0a02937608cebb19e8fad00def65',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/333d6191f491d81a3f627057319012e1.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a707a290e36d3ac6ad4ddaf963c48dbd',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/df7b53f268ebf5092159f07ddb0e14df.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '369a8df36870cc36cb076e6615701102',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/56ef4d699fd47394e39789202583bbdd.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30b21e0849dd0570ee27286805d7825e',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/79f190141a3b7c88c939280d2a00aca4.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6431bbe66d922f372e11e422a08a3a4',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/ddeaebdc0ba43aefe564664c8b070656.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfc858f7c5bb4fb3247af40aff71125c',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/2dce0a8db0a75c73693e31ef2e13ed1b.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9e1ae52381d5f511987b116338b3725',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/e30755b94431097ef606c6d263da988e.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6cc800fa5afe07a45e5d0be40ad974b',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/3b48f44e301d3667f1dba3b996ab040b.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69d30816e2cceebba3af81a6c265dfd6',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/e712f91bd8adcfb1582e168c32700900.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '231eaba1f4a5bde7796ecfb8956d4d7b',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/395e6378b36ad1d4310289c25f0c3413.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1c4a6ad5d5926544cac96a64fce21a5',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/dfe6746df80b0707736b20933defed1a.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db88cac79415ba3041ac1238140d26f1',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/9a2f74bb745d14ef4f996f29e8a8b412.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '821f3d1c96a0c8a912bafdec2c067ea3',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/f4da855d78885869fb4bbddd4bba7886.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4fab677b8a913f28a9e7d721853d626',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/f333b4676f54e2e7e568b95dd1787127.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf5605f510eab4b0d49feb428bba4449',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/bbfef866dfab398353c3df41a3c6e33c.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71a26270bfb649c8ad9f76289aca4f19',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/93cd36265b15441b184dc2d6bf4a2c92.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dba7ebf4a6bf3a1a054421693c993116',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/318056fc0e291bd9824d5fccbccc8971.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7beb6af691b07823171794b53161cdee',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/f0c7394a7cd3bfadc1ea17005bf4ec57.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca8d320dad60e443738aea6805addd73',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/61fe28bfd2c557c679d57e719ec9402c.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4143bb9ee2e775274ffff1d5caa57eb8',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/9fd520de0c06d1176905db433b48c53c.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '220bc7d17fc4f7e4f07a81f103cfc183',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/693a4ee3f8fdd97525a1211b8f1ea8e2.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75fb5c0023c16032db5f9857f4411531',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/74d337b0f40ae8c586682b8391c77d53.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecba883996e1565487fdbb160d23cd29',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/d53d4201a4e346322d4bc01ba89f2209.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa59659e9d065ca9aa8781aa205507a9',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/d093de76760912dfa7392098909f941b.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40142dda72c39104cac09bc774b63fa5',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/84f0c9acf65f247aae57febf56c8f621.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55bd155d7c588a3680d445adb584ef48',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/a58a6d17d35a905c2858f00975099469.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4e94278db4247cf8a6c6320c3fec452',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/ea20114c07a86ecd590aa9ee75db510f.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a31b1d7dbc292b87aee3128e887f569',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/021de9b74a5ce98c9d414e6003c15bf1.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d1efc24823527304895382a7dad76e2',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/1bade590cb58c5c3f675ad9c883e8733.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e24c6c00a68cff0cffe94453d679e48',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/4f0a0b6ebbfb1314fe2a2d71d2e4eacb.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4519270bec8a52e32ee993cdc5ea332a',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/07fe1c8e3dc19bee9d3d601606399f47.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b60339f1053f1828662063223a543e5',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/cead90fc8b3acb1f5c6c0457e010deff.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '466663efaf6fc418785ff1e5c0a68141',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/e29bdbc127b2c87dc38962275492b793.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd83fc494187a202bd58969404c2e765f',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/c018e4e7c032cc6f282168b70f1e7dce.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b384c84485d040d149be627cf409c5d5',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/396c5beb3e5893a4aaf554ff5ed752e3.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '698d023c55d3285d14ed6dee5edb0239',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/541ebcea89c071e970c615441f74885b.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb9184fe50a89875f20fb1b2b7e6fd4b',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/8ccaf5597b45e7b80f6eb82e65af2fb0.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6f9cfc81650db0b7099c46bcbeddda0',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/e1241e1f04f3fd6a5cbdbbbc352836e7.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8eaf61f2bcbd082f54f16be77b1461b',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/0d661331512659eb1c44d97838bc1cbe.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14f3f4201ffe765bc6c2d24cec5210c9',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/f167a04f6bf2b9b44a6f16fde9dd6c90.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fccb023493f29272c3acc6131b96c8b',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/7c027877ed7d6b85f34a8fdeaf4b2762.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc411be043704ac6e275eeac3e5b9e8f',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/253bf0b4bc5f6b4bc3ebf3281aa8b7e1.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd47cd7dd97da27b9679262782a9d030',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/c817c0e4fba676554e92ca811f4c79e0.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ab74b96c9475dcda88fc75e137d6bf0',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/ed9171840c9437153ea10efddeec63d5.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2ac7955a06b192da0df41ee95ede62e',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/f814015ec84237614affbe900c401180.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3389907f20b1d829b973051220487bae',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/20ef5915a1b089ddd209a2db17617dcf.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8051c92154308f68439c08c3368d80e',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/6613bacf4f64a056b936e2afefe0158e.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '968ff4656a558cb4539d9f48c872a996',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/d21272c39cae439a34abde426390ef66.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2333741f8cfd153cbbf87050a56935f9',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/1b49a21ec7ca71bdb761a55c98765b8c.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2b125d395b36196a19f4c1d34be7037',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/838b62ea60ae7154c75fd43f17c14480.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '675cff44435890956ed3f31f77a4a974',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/3f7c0657dd1bad6d1df272e954d02569.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb273435e926d48dd66513ac59ab2bf5',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/04f3437daf9d28298f75479a05349c62.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e1157518a0e1676a2710157c7734802',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/514bc2a931408198ea963705ef245e50.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47a510e7695772520bf95b2885b61b76',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/e39b9f178a659932e4a4174f60b85e3e.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2f28204eeca127004908e453fb5b860',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/c9e69ba2999b67d9beb5a0d4b4db5c81.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0612a86bdd590bc1e7d711e81b38872a',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/8626540c683028c1671e46f1429de7fc.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5c6cdea303845b0aea9d18fbf6b0598',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/4e5e4ec3df62443498cf690f2be8744e.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a953a3d4941d4098e87584185354c2f',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/245804833576d23efa1195f87c90a40e.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf327f6f9bc4864d67c0f7ad65b6b331',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/55851024fc8896fb2de2844e0f1a8037.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fce49678917559d29c2e976d90bcec7e',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/f45b95bce9ab6c868df2abbd1f63a412.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52dbdbc9751265e524decb18a7a4fce4',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/00d083f90d7c0d35f82ddf8336392672.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5972077e6db0d1eb4aba001faa93cc26',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/1c6f4ac27541660674ad8450a231baad.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62c3529fd612899ca4180db4336b9140',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/70304eee74ea286d1a5f4f7122cde186.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cc857d117ef986ae9f3c4435d56cac6',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/60824a4e55060bcb2131c18fbf7c423d.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d116da547b8630f1a95203ea89abe78',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/bbe0ec8a802d554d3a819aeac5c00c59.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'deb1743ff20851198cfd2dcdc21456eb',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/081b04e7d019ef4259ffa9269b4241ef.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f114b4cc0d9e0fad47cdbbd2e3c8a43',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/a00e145ffc07ef779284d8358e4d0289.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7cc14c56a3afb5cc25a200259398fd45',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/629fadf131a317784f7dd9bb1fcfdf5e.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6e6ab78ee5701c2f16b6aac37ee353b',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/26f03946bfe462b30500a28297bfc986.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae42e0f904e1fdc3dfad32b78e5953a3',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/898a891b1eeede74de8fe4a5fdcf936f.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04ea394fd0b9493fa6fce277c4cdb61d',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/3315c8dfd697c90a8898ee718d169b83.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f95ae13679ee4cabb77b919046568e5a',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/474e851317578b0300627539dd6c265f.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1239db9e70543a7901a01dc7063e0d90',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/469861408d51583e85819991d80b7011.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '941d31c6bda2211d1a0fd61abad3c453',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/a3d2e7430b872b60d73dcb72b61a2582.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce982a91d643f40a19e932078c029cf4',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/0cc512fe5d19aec91c18f291f4c31379.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6199a2df5c6fd539a70dfafd3866e4a',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/b73a3819bbc3846e91d97c36b99a7064.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2be36dcb5e8a3c11d4cd003225a1f5c3',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/ac0aabb9a5bb45ea458114a2601dc190.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c0d13f9f3dbfd0687eb4ebf8e61a43f',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/3c9d9cfb52e428e096071fe781ec4977.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cde8ae5bd5b322d7e6182b78df8f5c1',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/02a421a6a0320f03e7bda7ab907e015f.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1447cb08ee39d545bf2bde5ebd7e0660',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/742612ed7f88af93b3b4b0f75b4e0eee.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b7710d48c3b8d130a93df12aa60a84b',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/bd16c2936e37b384851bbde059d62144.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03831ab2ab7fff0a1bdcba504c0ba278',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/06eda46ae6527c110b2e0046a1c27bd8.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef75aa0ffacb2866de74a5d20032ca37',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/cc1cc1e4e6de25ffd42e15e5a2c6bdd5.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eb5b310aa42ab212a63ca192896318d',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/dcffe16d9e47f53cd90fe078adff8311.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5689db79cfd753ba3e675b48f52edf9c',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/711f4bccfb1d727d32ee28bad58fb40b.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41844c007c60aa1588a6a1218cf3b8bf',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/1cdf8cafd1a036173bd1d1a5bd0c32cc.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c27a4220886e13eb8cd1fa521fd04308',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/5f56d5c21be20d0026a033932fe38750.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46e8a0ddc88ab6a9c996cc216e49b244',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/a246135e9fb5cbd2335536776a695a97.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '151c0fd2d82e462eadaaa83f247a79b3',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/5a2e253d75db9d23a0e39c14dd622e81.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3e0c285787562ca5ea2a33487d5248c',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/4031c470df7b0829ff0f1c46317e1480.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f7aa258e68c60337cfa222a5b801d43',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/60bc3add19b28647eaded8270d2c08df.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9bb92edbba2a7665bf7bcfa7fdfe130',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/dd3ec160678790ba763b829dad0d24f5.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0043760d8f0c4784ecf7bbf2d661bd68',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/d023a376ee4854a7f2640ed8659e502a.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc6da4ab35efde859f5d9793d53730b6',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/5c2faa8931639d75b833b15c01329798.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1ecd16b1255a71a3fa367ab61efd34a',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/8b338926bbbe5944ebe512a61a454876.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f9fd5e048df06527376228680b23a23',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/1f7a59183437d37f30cc9ddae1496b57.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8904294f0cd3c993a2ba12e5298de0d6',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/a2d6df5b1d261f5ba8efe422881327a8.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88c2e286d15d8b5534cb5fa352a32845',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/7d4794b5e8c2a614b9ba1873796b06b6.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '92f6a4002d32bd8e86cbffe8fa910462',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/1ab70236add2e2a72b1cf447f61b466c.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '6f1a50935c9a64d69c836d4951125909',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/106ec5bf31d61846899b4873b188ec57.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'ed7fcd62ad7783a0e6c79afd0e30eef9',
      'native_key' => 1,
      'filename' => 'modUserGroup/55de75a7cced48afe56bba3a9924e0ad.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'cbdb93945bb33ef3a4c166db0cc4f7c5',
      'native_key' => 1,
      'filename' => 'modDashboard/b1281827a6807d526372790e1250ec08.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'aae6ec31166e283981966b408530496e',
      'native_key' => 1,
      'filename' => 'modMediaSource/9ae3b23b7d9de66501c10f8528bb079f.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'db01b96ab8e5813d24bbdac0b6c1cd26',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/74322c87d00e8ac70797bed011bc298a.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '16c4bde7aa4df7654b3bebf7b2c7e7ec',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/032bee13d10872b56e2c36019caed29b.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '91681c7d00397e2c5cf097a6c65cb419',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/274edee07318f3f1753df4ec2bf75ea7.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '3e4b333bc285279f5a4ca99f4718f9dd',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4926bed9f7980ae7191a4995feddaf5f.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'a79684f8f79fb5d3f05e7b273836bd42',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/9ab60579419f813c56b2fa492bb67150.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'e7e15f64cef5c101e2462fb7b6ddad59',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/2ef1d19a655960852952857ad5f87756.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '31d8b35b4d1864310a22da43962669b4',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/51aae0147999c4222f09a62e0ca738b2.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0f24faf32c4e78e5faa78385dd0ebb1d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/8ec42fdd94d1bedd05eb8053f95adb8b.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'b0e24c2ca476c44227f8ae277011e7de',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/9641f74f1fb6d6a700320556d8911186.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ebcfbc65660958107fed83bd71fedb1a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/40954363693ae585e5ccae75cf2aad80.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '253e0fa7b30cdb3d61ebd43c6ecb2cfb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2764969dfdab664a174c646c2c2da83f.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '117799767f9faeac35fc69d150acb680',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/99a266ca9dc76fa209504e4b49052f18.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '31d8adc9967fcd254ab6cfe4cf2bb9c2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1eab2bcad3be57c1f8e21ef7993d78e5.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '93e7dcb4a4b0d45ac961a8b948b633da',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c7f1ddc698c15b24e50294fd0fcf1580.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e9f1fae390014cad30ccb2dcdd195a97',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1e4a4a8ba92a7a0d6b1385858510a3a3.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '57e7e59d112d15c95b2a89c64f2cbdd5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/004242d857f10a3e79723d10c82b4d60.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '9c95ac5bdc0eb4532ff53a2301ebcc63',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f174e2ea1448c3b141ba18086a9ae052.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '00aa83c1339c0bf5d8ec4c97600764e5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ae75037d1bc19bf4565088e3871e9f9e.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5eff1942b51b93a74f497f28fd480e6b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d8d8c912e1db1f0dfaad89b0f9454f0d.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b47b38562b508854779076a1fd493e4c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b83a206e84ed02a9bc9c694067ec4215.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3ab28c452f91d99a3c475b3db07eafb8',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/9c6a062c88657b346720da227640a42d.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'bb2e9835f7f2e05ba0388c92b00fa3dd',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/1d35227c8a45df7b45d4695c3b3f300c.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6f81f20c0cfaf2949344c79f9b6087a5',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/95da25176a4a36e1ed5774b45e39040a.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c5c2aff26cfd67933e23c97a12db8770',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/f686b04f9f673653d10fde9a2bb78f11.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '089d58d23212f2fb7cf8d9b26f6935b0',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/aec98ebb21352e937a56959034c6a3b1.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '43fa9a198354d7141feea53d7c326c0e',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/35985b6a226337aa437ff1963a175da4.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '11c1a0b12661878fddca7f9d6b00746a',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/97146498646ee6794c837a63b58f66f8.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'dc4277c2e785778024fec500fd22285e',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/44e04f1e1b897438e836da77819aecfd.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '804bc0f58cffb8fbe050d413105b62e2',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/e3f5b23f821c4743c04b2bba3d91c0f5.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '37f717e8aed348ba0e75bc3ce1990772',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/7861585cde52d694f79bb11e8c7c0219.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '04a7222d941184b9ed0f5919fce2f605',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/71846c3723cdc715a00590bdce68e192.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7d2e68057c970343e5d828aecda649a8',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/b41eb20ce0ab6b1dfe282f303519b73b.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'b54e081baa435e3c8a5e517fc20d9b71',
      'native_key' => 'web',
      'filename' => 'modContext/e6d8cd72440164067d67b4aadd5abf5b.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '4fa52302aaf2e83ab83bd8373e05304f',
      'native_key' => 'mgr',
      'filename' => 'modContext/dbd60cfc2e61d378db1e8391698bb1e3.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '217098ef80088fd6b045f54e13aca091',
      'native_key' => '217098ef80088fd6b045f54e13aca091',
      'filename' => 'xPDOFileVehicle/72e44b8bbe58ed7724e7a4ec143c8619.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b6d2a3328f6b75adaf1847c3c00f45c4',
      'native_key' => 'b6d2a3328f6b75adaf1847c3c00f45c4',
      'filename' => 'xPDOFileVehicle/aac280a9bddd19904d30e707d382382c.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd36d11c0bb701c98cc092b9c93983617',
      'native_key' => 'd36d11c0bb701c98cc092b9c93983617',
      'filename' => 'xPDOFileVehicle/3215145fe43125e1e61de264fb0f13b2.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c6408fa2663b34d14c174fb79d658232',
      'native_key' => 'c6408fa2663b34d14c174fb79d658232',
      'filename' => 'xPDOFileVehicle/5b3189c294944b9523c7ace8554801cd.vehicle',
    ),
  ),
);